/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.util.ArrayList;

/**
 *
 * @author flani
 */
public class Controller {
    private ArrayList<Aluno> alunos = new ArrayList<>();
    
    public boolean salvar (Aluno a){
     if(a !=null){
         alunos.add(a);
         return true;
     }  else{
         return false;
     } 
    }
    public ArrayList<Aluno> retonarTodos(){
        return alunos;
    }
}
