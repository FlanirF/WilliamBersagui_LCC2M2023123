/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

/**
 *
 * @author flani
 */
public class Funcionario {
    private int id;
    private String Nome;
    private int Idade;
      private int Telefone;
    private String Genero;
    private String ArteMarcial;
    private double Salario;
    private String Morada;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the Nome
     */
    public String getNome() {
        return Nome;
    }

    /**
     * @param Nome the Nome to set
     */
    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    /**
     * @return the Idade
     */
    public int getIdade() {
        return Idade;
    }

    /**
     * @param Idade the Idade to set
     */
    public void setIdade(int Idade) {
        this.Idade = Idade;
    }

    /**
     * @return the Genero
     */
    public String getGenero() {
        return Genero;
    }

    /**
     * @param Genero the Genero to set
     */
    public void setGenero(String Genero) {
        this.Genero = Genero;
    }

    /**
     * @return the ArteMarcial
     */
    public String getArteMarcial() {
        return ArteMarcial;
    }

    /**
     * @param ArteMarcial the ArteMarcial to set
     */
    public void setArteMarcial(String ArteMarcial) {
        this.ArteMarcial = ArteMarcial;
    }

    /**
     * @return the Salario
     */
    public double getSalario() {
        return Salario;
    }

    /**
     * @param Salario the Salario to set
     */
    public void setSalario(double Salario) {
        this.Salario = Salario;
    }

    /**
     * @return the SalarioPago
     */
    public String getMorada() {
        return Morada;
    }

    /**
     * @param SalarioPago the SalarioPago to set
     */
    public void setMorada(String Morada) {
        this.Morada = Morada;
    }

    /**
     * @return the Telefone
     */
    public int getTelefone() {
        return Telefone;
    }

    /**
     * @param Telefone the Telefone to set
     */
    public void setTelefone(int Telefone) {
        this.Telefone = Telefone;
    }
    
    
}
