/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

/**
 *
 * @author flani
 */
public class Aluno {
    private int id;
    private String Nome;
    private int idade;
    private int telefone;
    private String Morada;
    private String Genero;
    private String Faixa;
    private String ArteMarcial;
     
     

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the Nome
     */
    public String getNome() {
        return Nome;
    }

    /**
     * @param Nome the Nome to set
     */
    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    /**
     * @return the Faixa
     */
    public String getFaixa() {
        return Faixa;
    }

    /**
     * @param Faixa the Faixa to set
     */
    public void setFaixa(String Faixa) {
        this.Faixa = Faixa;
    }

    /**
     * @return the idade
     */
    public int getIdade() {
        return idade;
    }

    /**
     * @param idade the idade to set
     */
    public void setIdade(int idade) {
        this.idade = idade;
    }

    /**
     * @return the telefone
     */
    public int getTelefone() {
        return telefone;
    }

    /**
     * @param telefone the telefone to set
     */
    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }

    /**
     * @return the Morada
     */
    public String getMorada() {
        return Morada;
    }

    /**
     * @param Morada the Morada to set
     */
    public void setMorada(String Morada) {
        this.Morada = Morada;
    }

    /**
     * @return the Genero
     */
    public String getGenero() {
        return Genero;
    }

    /**
     * @param Genero the Genero to set
     */
    public void setGenero(String Genero) {
        this.Genero = Genero;
    }

    /**
     * @return the ArteMarcial
     */
    public String getArteMarcial() {
        return ArteMarcial;
    }

    /**
     * @param ArteMarcial the ArteMarcial to set
     */
    public void setArteMarcial(String ArteMarcial) {
        this.ArteMarcial = ArteMarcial;
    }

    
}

