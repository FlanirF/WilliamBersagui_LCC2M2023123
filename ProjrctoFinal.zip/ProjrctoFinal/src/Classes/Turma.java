/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.util.ArrayList;

/**
 *
 * @author flani
 */
public class Turma {
     private int id;
    private String ArteMarcial;
    private Funcionario Instrutor;
    private ArrayList<Aluno> alunos;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the ArteMarcial
     */
    public String getArteMarcial() {
        return ArteMarcial;
    }

    /**
     * @param ArteMarcial the ArteMarcial to set
     */
    public void setArteMarcial(String ArteMarcial) {
        this.ArteMarcial = ArteMarcial;
    }

    /**
     * @return the Instrutor
     */
    public Funcionario getInstrutor() {
        return Instrutor;
    }

    /**
     * @param Instrutor the Instrutor to set
     */
    public void setInstrutor(Funcionario Instrutor) {
        this.Instrutor = Instrutor;
    }

    /**
     * @return the alunos
     */
    public ArrayList<Aluno> getAlunos() {
        return alunos;
    }

    /**
     * @param alunos the alunos to set
     */
    public void setAlunos(ArrayList<Aluno> alunos) {
        this.alunos = alunos;
    }
    
    public void AdicionarAluno(Aluno aluno) {
        alunos.add(aluno);
    }

    public void RemoverAluno(Aluno aluno) {
        alunos.remove(aluno);
    }


}
